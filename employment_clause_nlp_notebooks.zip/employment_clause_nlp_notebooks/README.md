# Employment Clause Classification NLP Starter Notebooks

Recommended order:

1. `01_data_exploration_and_filtering.ipynb`
   - Load LEDGAR from LexGLUE
   - Inspect labels
   - Filter employment-related classes
   - Export filtered train/validation/test CSV files

2. `02_baselines_tfidf_models.ipynb`
   - Random baseline
   - Majority baseline
   - TF-IDF + Logistic Regression
   - Optional TF-IDF + Linear SVM

3. `03_transformer_finetuning_legalbert.ipynb`
   - Fine-tune Legal-BERT-small first
   - Then try Legal-BERT-base
   - Optional comparison with BERT-base

4. `04_evaluation_and_error_analysis.ipynb`
   - Combine final metrics
   - Produce comparison plots
   - Support the results/discussion section

Install command:

```bash
pip install datasets transformers torch scikit-learn pandas numpy matplotlib seaborn evaluate accelerate
```

Suggested final scope:
- Random baseline
- Majority baseline
- TF-IDF + Logistic Regression
- TF-IDF + Linear SVM
- Legal-BERT-small or Legal-BERT-base
- Error analysis using macro-F1, weighted-F1, per-class metrics, and confusion matrices